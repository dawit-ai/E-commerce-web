import React from 'react'

export const Shop = () => {
  return (
    <div>Shop</div>
  )
}

