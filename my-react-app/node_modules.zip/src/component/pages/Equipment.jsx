import React from 'react';
import { getEquipment } from '../../Pictures/Equipment';
import { getEquipmentImgUrl } from '../../Show/equipment';
export const Equipment = () => {
  const equipment=getEquipment();
  return <>
{
  equipment.map(acc =>(
   <li key={acc.id}>
    <img src={getEquipmentImgUrl(acc.pic)} alt="" />
    <h1>{acc.title}</h1>
    <p>{acc.description}</p>
    <p>{`$${acc.Price}`}</p>
    <button>Buy Now</button>
   </li>
  ))
}
  </> 
};

