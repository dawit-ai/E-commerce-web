import React from 'react';
import { getAccessories } from '../../Pictures/Accessorie';
import { getAccessorieImgUrl } from '../../Show/accessorie-img-show';
export const Accessorie = () => {
  const accessorie=getAccessories();
  return <>
This is the Accessories page
{
  accessorie.map(acc =>(
   <li key={acc.id}>
    <img src={getAccessorieImgUrl(acc.pic)} alt="" />
    <h1>{acc.title}</h1>
    <p>{acc.description}</p>
    <p>{`$${acc.Price}`}</p>
    <button>Buy Now</button>
   </li>
  ))
}
  </> 
};
