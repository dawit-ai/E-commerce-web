import React from 'react'

export const Cart = ({handleClike}) => {
  return (
    <div>
  {
    Cart.map(item=>(
      <li>
        
      </li>
    ))
  }
    </div>
  )
}
