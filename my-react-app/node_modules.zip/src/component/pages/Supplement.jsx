import React from 'react'
import { getsupplements } from '../../Pictures/Supplements'
import { getSupplementImgUrl } from '../../Show/supplement'
export const Supplement = () => {
  const supplement=getsupplements();
  return (
    
    <div>Supplements
      {
        supplement.map(supp=>(
         <li key={supp.id}>
          <img src={getSupplementImgUrl(supp.pic)} alt="" />
          <h1>{supp.title}</h1>
          <p>{supp.description}</p>
          <p>{`$${supp.Price}`}</p>
          <button>Buy Now</button>
         </li>
        ))
      }
    </div>
  )
}

